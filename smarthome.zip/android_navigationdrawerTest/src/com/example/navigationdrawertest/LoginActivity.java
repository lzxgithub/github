package com.example.navigationdrawertest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener {

	private EditText etAccount;
	private EditText etPassword;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		initViews();
	}

	private void initViews() {
		// TODO Auto-generated method stub
		etAccount = (EditText) findViewById(R.id.etAccount);
		etPassword = (EditText) findViewById(R.id.etPassword);
		findViewById(R.id.bntLogin).setOnClickListener(this);
		findViewById(R.id.bntBack).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
			case R.id.bntLogin: {
				String account = etAccount.getText().toString();
				String password = etPassword.getText().toString();
				if (account == null || password == null || account.trim().equals("")
						|| password.trim().equals("")) {
					Toast.makeText(this, "�û���¼�����벻��Ϊ��", Toast.LENGTH_LONG).show();
				}else{
					if(account.equals("stone") && password.equals("123")){
//						Toast.makeText(this, "��¼�ɹ�", Toast.LENGTH_LONG).show();
						Intent intent = new Intent(this,MainActivity.class);
						startActivity(intent);
					}else{
						Toast.makeText(this, "��¼ʧ�ܣ��û���������������", Toast.LENGTH_LONG).show();
						
					}
				}
				break;
			}
			case R.id.bntBack: {
				finish();
				break;
			}
		}
	}
}
